﻿export function createDefaultIcon() {
    return new L.Icon.Default();
}