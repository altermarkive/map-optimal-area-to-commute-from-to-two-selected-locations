﻿export function showPrompt(message) {
    return alert(message);
}
